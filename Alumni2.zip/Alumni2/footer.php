<footer class="footer">
    <p>&copy; <?php echo date("Y"); ?> AlumSphere | All Rights Reserved  | Developed for IT2212 Project | Contact Us:alumsphere@vau.ac.lk</p>
</footer>
